# for 
# while 
# Iterating loop
import time
s = "hello world"
l = ["mon","tue","wed","thurs","frida"]
# iterating variable
# for i in l:
#     print("iterating variable",i)
    
# for a in range(0,1000):
#     print(a*2)
# break 
# continue 
# pass 


i = 0
while (i <= 100):
    print(i)
    i = i +1
    time.sleep(1)
   
else:
    print("printing done")
    