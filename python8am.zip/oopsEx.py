# def person(a,b):

from student import StudentDatabase as sd

print(sd.student)
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age  
        
    def printName(self):
        print(self.name) 
        
    def printAge(self):
        print(self.age) 
        
        
class Person1:
    def __init__(self, name, age):
        self.name = name
        self.age = age  
        
    def printName(self):
        print(self.name) 
        
    def printAge(self):
        print(self.age) 
# p = Person("Python", 30)  

# p.printName()
# p.printAge()
