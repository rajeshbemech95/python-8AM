# i = int(i)
# print(type(i))
# python operators
# Arithmetic operators  +-*/%
# Comparative operators < > <= >= == =!
# logical operators and or not 
#conditional statements
# if 
# else
# elif

a = int(input("Enter first value"))
b = int(input("Enter Seccond Value"))


if(b == 0) or (b <a):
    print("B is Zero cannot perform division",b)
elif(b<a):
    print("bi s graeter than a")
    
elif():
    
else:
    c = a/b
    print(c)
    
print("application exit")    


    
    




