
# Varriable (data/ data Structure)
# Loops
# Functions 

# misc

# object (oops)

# modules

# Variable (data/ data Structure)

# Variable name 
# Value 
# Data Type 

a = "hel\nlo"
b = "10"
c = 0.5
d = [1,2,3,4,5]

print("printing\n output")
print(type(a))
print(type(c))
print(type(d))
print(type(b))


i = input("enter your input")
print(i)
print(type(i))
# inteiger int 0-10
# Chracter str "asdfghjklllllllll1234567890!@#$%^&"
# Decimal float 0.12

# list [1,2,3,4,5]
# tuple (1,2,3,4)
# set {1,2,3,4}


# bit  0 1
# byte 8x bit 
# Kbyte   1024x Byte




